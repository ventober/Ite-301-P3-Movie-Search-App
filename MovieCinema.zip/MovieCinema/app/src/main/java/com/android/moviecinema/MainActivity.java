package com.android.moviecinema;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    private static MainActivity instance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;
        countRecords();
        readRecords();
        Button buttonCreateMovie = (Button) findViewById(R.id.buttonCreateMovie);
        buttonCreateMovie.setOnClickListener(new OnClickListenerCreateMovie());
    }
    public static MainActivity getInstance() {
        return instance;
    }
    protected void onResume() {
        super.onResume();
        countRecords();
        readRecords();
    }
    public void countRecords() {
        int recordCount = new TableControllerMovie(this).count();
        TextView textViewRecordCount = (TextView) findViewById(R.id.textViewRecordCount);
        textViewRecordCount.setText(recordCount + " records found.");
    }

    public void readRecords() {
        LinearLayout linearLayoutMovies = (LinearLayout)
                findViewById(R.id.linearLayoutMovies);
        linearLayoutMovies.removeAllViews();
        List<Movie> movies = new TableControllerMovie(this).read();
        if (movies.size() > 0) {
            for (Movie obj : movies) {
                int id = obj.id;
                String title = obj.title;
                String genre = obj.genre;
                String director = obj.director;
                String textViewContents = id + " : " + title + " - " + director + "(" +
                        genre + ")";
                TextView textViewMovieItem = new TextView(this);
                textViewMovieItem.setPadding(0, 10, 0, 10);
                textViewMovieItem.setText(textViewContents);
                textViewMovieItem.setTag(Integer.toString(id));
                textViewMovieItem.setOnLongClickListener(new
                        OnLongClickListenerMovieRecord());
                linearLayoutMovies.addView(textViewMovieItem);
            }
        }else{
            TextView textViewMovieItem = new TextView(this);
            textViewMovieItem.setPadding(8, 8, 8, 8);
            textViewMovieItem.setText("No records found.");
            linearLayoutMovies.addView(textViewMovieItem);
        }
    }
}